#include <stdio.h>
    #include <stdlib.h>
    #include <string.h>
    #include <ctype.h>
    #include "contact.h"
    #include "file.h"

    int is_valid_name();
    int is_valid_phone();
    int is_valid_email();
    int unique_phone();
    int unique_email();
   // int editsearch=-1;
    //int count=1;
    void listContacts(AddressBook *addressBook) 
    {
        if(addressBook->contactCount == 0)
        {
            printf("The address book is empty.\n");
            return;
        }
        printf("Contacts in the address book:\n");
        for(int i=0;i<addressBook->contactCount;i++)
        {
            printf("%d.Contact\n",i+1);
            printf("Name:%s\n",addressBook->contacts[i].name);
            printf("Phone Number:%s\n",addressBook->contacts[i].phone);
            printf("Email:%s\n",addressBook->contacts[i].email);
            printf("-------------------------------\n");
        }
    }

    void initialize(AddressBook *addressBook) 
    {
        addressBook->contactCount = 0;
        
        // Load contacts from file during initialization (After files)
        //loadContactsFromFile(addressBook);
        
    }

    void saveAndExit(AddressBook *addressBook) 
    {
        saveContactsToFile(addressBook);  // Save contacts to file
       
    }


    void createContact(AddressBook *addressBook)
    {
        printf("(contact count => %d)\n",addressBook->contactCount);
        N:
        printf("Enter the name : ");
        char name[100];
        int result;
        scanf(" %[^\n]",name);
        
        result=is_valid_name(name);
        if(result==1)
        {
            printf("%s\n",name);
            strcpy(addressBook->contacts[addressBook->contactCount].name,name);
        }
        else
        {
            printf("Invalid Name.Try again\n");
            goto N;
        }
        
        char phone[11];
        while (1) 
        {
            printf("Enter the Phone Number: ");
            scanf(" %[^\n]", phone);

            if (!is_valid_phone(phone)) 
            {
                printf("Invalid phone number.Try again.\n");
                continue;
            }
            // Check for uniqueness
            if (unique_phone(addressBook,phone)) 
            {
                printf("Phone number already exists. Please enter a unique number.\n");
                continue;
            }
            strcpy(addressBook->contacts[addressBook->contactCount].phone, phone);
            printf("%s\n",phone);
            break;
        }

        char email[50];
        while (1) 
        {
            printf("Enter the Email: ");
            scanf(" %[^\n]",email);

            if (!is_valid_email(email)) 
            {
                printf("Invalid email.Try again.\n");
                continue;
            }
            // Check for uniqueness
            if (unique_email(addressBook,email)) 
            {
                printf("Email already exists. Please enter a unique email.\n");
                continue;
            }
            strcpy(addressBook->contacts[addressBook->contactCount].email,email);
            printf("%s\n",email);
            break;
        }
        
        printf("contact count = %d\n",addressBook->contactCount);

        addressBook->contactCount++;   
    }

    /*void searchContact(AddressBook *addressBook) 
{
    if (addressBook->contactCount == 0) 
    {
        printf("Address book is empty. No contacts to search.\n");
        return;
    }
    
    int choice;
    char search[100];
    int flag=0;
    int i=0;
    printf("1.search contact by name\n");
    printf("2.search contact by number\n");
    printf("3.search contact by email\n");
    printf("Enter your choice:");
    scanf("%d",&choice);
    switch(choice)
    {
        case 1://search by name
            printf("Enter the name:");
            scanf(" %[^\n]",search);

            for(int i=0;i<=addressBook->contactCount;i++)
            {
                if(strcmp(addressBook->contacts[i].name,search) == 0)
                {
                    printf("Contact found\n");
                    printf("Name:%s\n",addressBook->contacts[i].name);
                    printf("Number:%s\n",addressBook->contacts[i].phone);
                    printf("Email:%s\n",addressBook->contacts[i].email);
                    flag=1;
                    count++;
                }
            }
        break;

        case 2://search by number
            printf("Enter the number:");
            scanf(" %[^\n]",search);

            for(int i=0;i<=addressBook->contactCount;i++)
            {
                if(strcmp(addressBook->contacts[i].phone,search) == 0)
                {
                    printf("Contact found\n");
                    printf("Name:%s\n",addressBook->contacts[i].name);
                    printf("Number:%s\n",addressBook->contacts[i].phone);
                    printf("Email:%s\n",addressBook->contacts[i].email);
                    flag=1;
                    break;
                }
            }
        break;

        case 3://search by email
            printf("Enter the email:");
            scanf(" %[^\n]",search);

            for(int i=0;i<=addressBook->contactCount;i++)
            {
                if(strcmp(addressBook->contacts[i].email,search) == 0)
                {
                    printf("Contact found\n");
                    printf("Name:%s\n",addressBook->contacts[i].name);
                    printf("Number:%s\n",addressBook->contacts[i].phone);
                    printf("Email:%s\n",addressBook->contacts[i].email);
                    flag=1;
                    break;
                }
            }
            break;
        
        default:
            printf("Enter valid option\n");
    }
    if(!flag) 
    {
        printf("Contact not found\n");
        editsearch=-1;
    }
    else
    {
        editsearch=i;
    }
}

void editContact(AddressBook *addressBook)
{
    char edit[100];
    char name[100];
    char number[100];
    char email[100];
    int n;
    if (addressBook->contactCount == 0) 
    {
        printf("Address book is empty. No contacts to edit.\n");
        return;
    }
    searchContact(addressBook);
    while(1)
    {
        if(count>0)
        {
            printf("Multiple contacts under same name.So search by number.\n");
            count=0;
            searchContact(addressBook);
        }
        if(editsearch==-1)
        {
            printf("The entered contact details are not in the address book.\n");
            printf("Try again.v \n");
            //continue;
            break;
        }

        printf("What would you like to edit:\n");
        printf("1.Edit contact by name\n");
        printf("2.Edit contact by phone number\n");
        printf("3.Edit contact by email\n");
        printf("Enter your choice: ");
        scanf("%d",&n);
        switch(n)
        {
            case 1:
            
            while(1)
            {
                printf("Enter new name:\n");
                scanf(" %[^\n]",name);
                if(is_valid_name(&name))
                {
                    printf("Updated new name:%s",name);
                    strcpy(addressBook->contacts[editsearch].name,name);
                    break;
                }
                else
                {
                    printf("Invalid name\n");
                }
            }
            break;
            case 2:
            while(1)
            {
                printf("Enter new Phone Number: ");
                scanf(" %[^\n]",number);

                if (is_valid_phone(number)) 
                {
                    printf("Invalid phone number.Try again.\n");
                    continue;
                }
                // Check for uniqueness
                if (unique_phone(addressBook,number)) 
                {
                    printf("Phone number already exists. Please enter a unique number.\n");
                    continue;
                }
                strcpy(addressBook->contacts[editsearch].phone,number);
                printf("%s\n",number);
                break;
            }
            break;

            case 3:
            char email[100];
            while (1) 
            {
                printf("Enter new email: ");
                scanf(" %[^\n]",email);

                if (is_valid_email(email)) 
                {
                    printf("Invalid email.Try again.\n");
                    continue;
                }
                // Check for uniqueness
                if (unique_email(addressBook,email)) 
                {
                    printf("Email already exists. Please enter a unique email.\n");
                    continue;
                }
                strcpy(addressBook->contacts[editsearch].email,email);
                printf("%s\n",email);
                break;
            }
            break;

            default:
                printf("Invalid choice\n");
                continue;
        }
        break;
    }
}

    int searchContact(AddressBook *addressBook,int *matchindex) 
    {
        int choice;
        char searchname[100];
        int matchCount = 0;
        int match;

        printf("1. search contact by name\n");
        printf("2. search contact by phone number\n");
        printf("3. search contact by email\n");
        printf("enter your choice: ");
        scanf("%d",&choice);
        switch(choice)
        {
            case 1:
            printf("Enter the name to be searched : ");
            scanf(" %[^\n]",searchname);
            
            for(int i=0;i<addressBook->contactCount;i++)
            {
              match=0;
              if(strcmp(addressBook->contacts[i].name,searchname) == 0)
              {
               //printf("Contact found\n");
               printf("Name:%s\n",addressBook->contacts[i].name);
               printf("Phone Number:%s\n",addressBook->contacts[i].phone);
               printf("Email:%s\n",addressBook->contacts[i].email);
               match=1;
               matchindex[matchCount++] = i;
               }
            }
            break;

            case 2:
            printf("Enter the phone number to be searched : ");
            scanf(" %[^\n]",searchname);
            for(int i=0;i<addressBook->contactCount;i++)
            {
                match=0;
                if(strcmp(addressBook->contacts[i].phone,searchname) == 0)
                {
                printf("Contact found\n");
                printf("Name:%s\n",addressBook->contacts[i].name);
                printf("Phone Number:%s\n",addressBook->contacts[i].phone);
                printf("Email:%s\n",addressBook->contacts[i].email);
                match=1;
                matchindex[matchCount++] = i;
                break;
                }
            } 
            break;

            case 3:
            printf("Enter the email to be searched : ");
            scanf(" %[^\n]",searchname);
            for(int i=0;i<addressBook->contactCount;i++)
            {
                match=0;
                if(strcmp(addressBook->contacts[i].email,searchname) == 0)
                {
                printf("Contact found\n");
                printf("Name:%s\n",addressBook->contacts[i].name);
                printf("Phone Number:%s\n",addressBook->contacts[i].phone);
                printf("Email:%s\n",addressBook->contacts[i].email);
                match=1;
                matchindex[matchCount++]=i;
                break;
                }
            }
            break;

            default:
            printf("Invalid\n");
        }
        if (matchCount == 0) 
        {
            printf("No matching contact found.\n");
        } 
        return matchCount;
    }*/

    void searchContact(AddressBook *addressBook) 
    {
        int choice,match,count=0;
        char searchname[100];
        
        printf("1. search contact by name\n");
        printf("2. search contact by phone number\n");
        printf("3. search contact by email\n");
        printf("enter your choice: ");
        scanf("%d",&choice);
        switch(choice)
        {
            case 1:
            printf("Enter the name to be searched : ");
            scanf(" %[^\n]",searchname);
            
            for(int i=0;i<addressBook->contactCount;i++)
            {
              if(strcmp(addressBook->contacts[i].name,searchname) == 0)
              {
               printf("Match %d:\n", count + 1);
               printf("Name:%s\n",addressBook->contacts[i].name);
               printf("Phone Number:%s\n",addressBook->contacts[i].phone);
               printf("Email:%s\n",addressBook->contacts[i].email);
               count++;
               }
            }
            break;

            case 2:
            printf("Enter the phone number to be searched : ");
            scanf(" %[^\n]",searchname);
            for(int i=0;i<addressBook->contactCount;i++)
            {
                if(strcmp(addressBook->contacts[i].phone,searchname) == 0)
                {
                printf("Match %d:\n", count + 1);
                printf("Name:%s\n",addressBook->contacts[i].name);
                printf("Phone Number:%s\n",addressBook->contacts[i].phone);
                printf("Email:%s\n",addressBook->contacts[i].email);
                count++;
                break;
                }
            } 
            break;

            case 3:
            printf("Enter the email to be searched : ");
            scanf(" %[^\n]",searchname);
            for(int i=0;i<addressBook->contactCount;i++)
            {
                if(strcmp(addressBook->contacts[i].email,searchname) == 0)
                {
                printf("Match %d:\n", count + 1);
                printf("Name:%s\n",addressBook->contacts[i].name);
                printf("Phone Number:%s\n",addressBook->contacts[i].phone);
                printf("Email:%s\n",addressBook->contacts[i].email);
                count++;
                break;
                }
            }
            break;

            default:
              printf("Invalid\n");
              return;
        }
        if(count == 0)
        {
            printf("contact not found\n");
        }
        
    }
           


    void editContact(AddressBook *addressBook)
    {
        int editindex=-1;
        int editchoice;
        char name[100];
        char edit[100];
        int matchindex[50];
        int matchcount=0;

        while(1)
        {
            //printf("\n--- Searching for Contact to Edit ---\n");
            M:
            searchContact(addressBook);  
            
            printf("\nHow many contacts matched in your search? Enter the count: ");
            scanf("%d", &matchcount);

            if (matchcount == 0)
            {
                printf("No matching contacts found. Try again.\n");
                return;
            }
            else if(matchcount>1)
            {
                printf("\nMultiple contacts found.So go with below choice");
                goto M;
            } 
            int contactNumber;
           /* printf("Enter the exact match to edit (e.g., Contact 1, Contact 2): ");
            
            scanf("%d", &contactNumber);
            if (contactNumber <= 0 || contactNumber > addressBook->contactCount)
            {
                printf("Invalid selection. Try again.\n");
                continue;
            }*/
            editindex = contactNumber - 1;

        break;
        }

        while(1)
        {
           
            printf("\nWhat would you like to edit?\n");
            printf("1.Edit contact by name\n");
            printf("2.Edit contact by phone number\n");
            printf("3.Edit contact by email\n");
            printf("Enter your choice: ");
            scanf("%d",&editchoice);
            
            switch(editchoice)
            {
                case 1:
                while(1)
                {
                    printf("Enter New Name:\n");
                    scanf(" %[^\n]",name);
                    if(is_valid_name(name))

                    {
                        printf("Updated new name:%s",name);
                        strcpy(addressBook->contacts[editindex].name,name);
                        break;  
                    }
                    else
                    {
                        printf("Invalid name\n");
                    }
                }
                break;
                char phone[11];
                case 2:
                
                while (1) 
                {
                    printf("Enter new Phone Number: ");
                    scanf(" %[^\n]",phone);

                    if (!is_valid_phone(phone)) 
                    {
                        printf("Invalid phone number.Try again.\n");
                        continue;
                    }
                    // Check for uniqueness
                    if (unique_phone(addressBook,phone)) 
                    {
                        printf("Phone number already exists. Please enter a unique number.\n");
                        continue;
                    }
                    strcpy(addressBook->contacts[editindex].phone,phone);
                    printf("%s\n",phone);
                    break;
                }
                break;
                char email[100];
                case 3:
                while (1) 
                {
                    printf("Enter new email: ");
                    scanf(" %[^\n]",email);

                    if (!is_valid_email(email)) 
                    {
                        printf("Invalid email.Try again.\n");
                        continue;
                    }
                    // Check for uniqueness
                    if (unique_email(addressBook,email)) 
                    {
                        printf("Email already exists. Please enter a unique email.\n");
                        continue;
                    }
                    strcpy(addressBook->contacts[editindex].email,email);
                    printf("%s\n",email);
                    break;
                }
                break;

                default:
                printf("Invalid choice\n");
                continue;
            }
            break;
        }
    }

   void deleteContact(AddressBook *addressBook) 
    {
        int i, j, choice, found = 0;
        char input[100];

        printf("1. Delete contact by name\n");
        printf("2. Delete contact by phone number\n");
        printf("3. Delete contact by email\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        printf("Enter the value to search for: ");
        scanf("%s", input);

        printf("Matching contacts:\n");
        for (i = 0; i < addressBook->contactCount; i++) 
        {
            int match = 0;
            if (choice == 1 && strcmp(addressBook->contacts[i].name, input) == 0) 
            {
                match = 1;
            } 
            else if (choice == 2 && strcmp(addressBook->contacts[i].phone, input) == 0) 
            {
                match = 1;
            } 
            else if (choice == 3 && strcmp(addressBook->contacts[i].email, input) == 0) 
            {
                match = 1;
            }

            if (match) 
            {
                printf("%d.Name:%s\n",i+1,addressBook->contacts[i].name);
                printf(" Phone Number:%s\n",addressBook->contacts[i].phone);
                printf(" Email:%s\n",addressBook->contacts[i].email);
                found = 1;
            }
        }

        if (!found) 
        {
            printf("No contact found matching the given input.\n");
            return;
        }

        printf("Enter the number of the contact to delete: ");
        int contactIndex;
        scanf("%d", &contactIndex);
        contactIndex--; 

        for (j = contactIndex; j < addressBook->contactCount - 1; j++) 
        {
            addressBook->contacts[j] = addressBook->contacts[j + 1];
        }

        addressBook->contactCount--; // Reduce the contact count
        printf("Contact deleted successfully.\n");
    }

   
      
    int is_valid_name(char *name)
    {
        int flag=0;
        for (int i = 0;name[i] != '\0';i++) 
        {
            if ((name[i] >= 'A' && name[i] <= 'Z') || (name[i] >= 'a' && name[i] <= 'z') || name[i] == ' ')
            {
                flag=0; 
            }
            else
            {
                flag=1;
                break;
            }
        }
        if(flag==0)
        return 1;
        else
        return 0;
    } 

    int is_valid_phone(char *phone) 
    {
        if (strlen(phone) != 10) 
        {
            return 0;
        }

        for (int i=0;phone[i] != '\0';i++) 
        {
            if (phone[i] < '0' || phone[i] > '9') // to check digit
            {
                return 0;
            }
        }
        return 1;
    }

    
    int is_valid_email(char *email) 
    {
        int at_index = -1, dot_index = -1;

        for (int i = 0; email[i] != '\0'; i++) 
        {
            if (email[i] == '@') {
                if (at_index != -1) 
                {
                    return 0;
                }
                at_index = i;
            } 
            else if (email[i] == '.' && email[i+1] == 'c' && email[i+2] == 'o' && email[i+3] == 'm' && email[i+4] == '\0') 
            {
                dot_index = i;
            }
        }

        if (at_index == -1 || dot_index == -1 || at_index == 0 || dot_index <= at_index + 1) 
        {
            return 0;
        }
        // Check for alphanumeric characters before '@'
        int has_alnum_before_at = 0;
        for (int i = 0; i < at_index; i++) 
        {
            if (isalnum(email[i])) 
            {
                has_alnum_before_at = 1;
                break;
            }
        }

        if(has_alnum_before_at)
        {
            return 1;
        }
        return 0;
    }

    int unique_phone(AddressBook *addressBook, char *phone) 
    {
        for (int i = 0; i < addressBook->contactCount; i++) 
        {
            if (strcmp(addressBook->contacts[i].phone,phone) == 0) 
            {
                return 1; 
            }
        }
        return 0; // Phone number is unique
    }
    
    int unique_email(AddressBook *addressBook, char *email) 
    {
        for (int i = 0; i < addressBook->contactCount; i++) 
        {
            if (strcmp(addressBook->contacts[i].email,email) == 0) 
            {
                return 1; 
            }
        }
        return 0; // email is unique
    }