#include <stdio.h>
#include "file.h"
#include <stdlib.h>
#include <string.h>

void saveContactsToFile(AddressBook *addressBook) 
{
    FILE *fptr=fopen("contacts.csv","w");
        if(fptr==NULL)
        {
            printf("file is not opened\n");
            return;
        }
        for (int i = 1; i <= addressBook->contactCount; i++) 
        {
            fprintf(fptr, "Name:%s,Phone Number:%s,Email:%s\n",addressBook->contacts[i-1].name,addressBook->contacts[i-1].phone,addressBook->contacts[i-1].email);
        }
        fclose(fptr);
        printf("contacts saved successfully\n");
        exit(EXIT_SUCCESS); // Exit the program
}

void loadContactsFromFile(AddressBook *addressBook) 
{
    FILE *fptr = fopen("contacts.csv", "r");
    if (fptr == NULL) 
    {
        printf("File could not be opened.\n");
        return;
    }

    char buffer[256];
    int lineCount = 0;

    // Skip the header line (if present)
    fgets(buffer, sizeof(buffer), fptr);

    while (fgets(buffer, sizeof(buffer), fptr)) 
    {
        if (lineCount >= addressBook->contactCount) 
        {
            printf("No more space to load contacts.\n");
            break;
        }

        char *name = strtok(buffer, ",");
        char *phone = strtok(NULL, ",");
        char *email = strtok(NULL, "\n");

        if (name == NULL || phone == NULL || email == NULL) 
        {
            printf("Invalid line format.\n");
            continue;
        }

        // Store contact information
        strcpy(addressBook->contacts[lineCount].name, name);
        strcpy(addressBook->contacts[lineCount].phone, phone);
        strcpy(addressBook->contacts[lineCount].email, email);

        lineCount++;
    }

    fclose(fptr);
    addressBook->contactCount = lineCount;
    printf("Contacts loaded successfully. Total Contacts: %d\n", addressBook->contactCount);
}